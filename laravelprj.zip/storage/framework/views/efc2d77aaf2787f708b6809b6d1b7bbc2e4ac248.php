<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php if(auth()->guard()->check()): ?>
        <h1>You are Successfully loged</h1>
        <form action="/logout" method="post">
            <?php echo csrf_field(); ?>
            <button>logout</button>
        </form>

        <br>
        <div style="border: 3px solid #9cff5b;">
            <h2>Create a New Post</h2>
            <form action="/create-post" method="POST">
                <?php echo csrf_field(); ?>
                <input type="text" name="title" placeholder="post title">
                <textarea name="body" placeholder="body content..."></textarea>
                <button>Save Post</button>
            </form>
        </div>

        <h2>Our Post</h2>
        <form action="/filter" method="get">
            
            <input type="text" name="title" placeholder="Search For ...">
            <button>Search</button>
        </form>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="background-color: #c2c2c2; padding: 10px; margin: 10px;">
                <h4><?php echo e($post['title']); ?> by : <?php echo e($post->userPostName->name); ?></h4>
                <p><?php echo e($post['body']); ?></p>
                <p><a href="/edit-post/<?php echo e($post->id); ?>">Edit</a></p>
                <form action="/delete-post/<?php echo e($post->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button>Delete</button>
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div style="border: 3px solid black;">
            <h2>Register</h2>
            <form action="/register" method="POST">
                <?php echo csrf_field(); ?>
                <input name="name" type="text" placeholder="name">
                <input name="email" type="text" placeholder="email">
                <input name="password" type="password" placeholder="password">
                <button>Register</button>
            </form>
        </div>
        <br><br>
        <div style="border: 3px solid black;">
            <h2>Login</h2>
            <form action="/login" method="POST">
                <?php echo csrf_field(); ?>
                <input name="loginname" type="text" placeholder="name">
                <input name="loginpassword" type="password" placeholder="password">
                <button>Login</button>
            </form>
        </div>

    <?php endif; ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravelprj\resources\views/home.blade.php ENDPATH**/ ?>