<?php

use App\Http\Controllers\PostController;
use App\Http\Controllers\UserController;
use App\Models\Post;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    $ourPosts = [];

    if (auth()->check()) {
        // $ourPosts = Post::where('user_id',auth()->id())->get();
        // Other metode
        // $ourPosts = auth()->user()->userPosts()->latest()->get();

        $ourPosts = Cache::remember('ourPosts', now()->addSeconds(200), function () {
            return auth()->user()->userPosts()->latest()->get();
        });
        // $ourPosts = $cachedData;
        // dd($cachedData);
    }
    return view('home', ['posts' => $ourPosts]);
});

Route::post('/register', [UserController::class, 'register']);
Route::post('/logout', [UserController::class, 'logout']);

Route::post('/login', [UserController::class, 'login']);
Route::post('/create-post', [PostController::class, 'createpost']);

Route::put('/edit-post/{post}', [PostController::class, 'updatePost']);

Route::delete('/delete-post/{post}', [PostController::class, 'deletePost']);
Route::get('/edit-post/{post}', [PostController::class, 'editpost']);

// Route::middleware(['isUser'])->group(function () {
// });

Route::get('/filter',[PostController::class,'filterPost']);