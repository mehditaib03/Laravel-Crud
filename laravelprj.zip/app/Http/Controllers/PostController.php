<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

use function PHPUnit\Framework\returnSelf;

class PostController extends Controller
{

    public function createpost(Request $request)
    {
        $validinputs = $request->validate([
            'title' => 'required',
            'body' => 'required',
        ]);

        $validinputs['title'] = strip_tags($validinputs['title']);
        $validinputs['body'] = strip_tags($validinputs['body']);
        $validinputs['user_id'] = auth()->id();

        Post::create($validinputs);
        return redirect('/');
    }

    public function editpost(Post $post)
    {
        if (auth()->id() !== $post['user_id']) {
            return redirect('/');
        }

        return view('edit', ['post' => $post]);
    }

    public function updatePost(Post $post, Request $request)
    {
        if (auth()->id() !== $post['user_id']) {
            return redirect('/');
        }

        $validinputs = $request->validate([
            'title' => 'required',
            'body' => 'required'
        ]);

        $validinputs['title'] = strip_tags($validinputs['title']);
        $validinputs['body'] = strip_tags($validinputs['body']);

        $post->update($validinputs);
        return redirect('/');
    }

    public function deletePost(Post $post)
    {
        if (auth()->id() === $post['user_id']) {
            $post->delete();
        }
        return redirect('/');
    }

    public function filterPost(Request $request)
    {
        $validinputs = $request->validate([
            'title'  => 'required'
        ]);
        
        $post = Post::where('title', 'LIKE','%' .$validinputs['title']. '%')->orWhere('title', 'like', '%'.$validinputs['title'].'%')->get();
        // dd($post);
        return  view('home', ['posts' => $post]);
    }
}
